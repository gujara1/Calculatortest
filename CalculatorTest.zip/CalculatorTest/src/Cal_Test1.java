import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Cal_Test1 {
	
	public static String calculate(String input1, String input2, int operation) {
		
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://www.calculator.net/");
		
		for(int i=0;i<input1.length();i++) {	
			driver.findElement(By.xpath("//span[text()='"+input1.charAt(i)+"']")).click();
		}
		
		if (operation==1)
			driver.findElement(By.xpath("//span[text()='+']")).click();
		
		else if (operation==2)
			driver.findElement(By.xpath("//span[text()='�']")).click();
		  
		else if (operation==3)
			driver.findElement(By.xpath("//span[text()='�']")).click();
		
		else
			driver.findElement(By.xpath("//span[text()='/']")).click();
		
		for(int i=0;i<input2.length();i++) {
			driver.findElement(By.xpath("//span[text()='"+input2.charAt(i)+"']")).click();	
		}
		
		driver.findElement(By.xpath("//span[text()='=']")).click();
		
		WebElement result=	driver.findElement(By.xpath("//div[@id=\"sciOutPut\"]"));
		
		String num=result.getText();
		
		return num;
	}
	
	
	public static void main(String[] args) {
		
		//read the inputs
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please enter your first Input: ");
		String input1=sc.nextLine();
		
		System.out.println("Please enter your second Input: ");
		String input2=sc.nextLine();
		
		//read the operation
		System.out.println("Select any one of the below operation ");
		System.out.println("1 for Addition || 2 for substraction || 3 for multiplication || 4 for Division");
		
		int operation=sc.nextInt();
		
		//call calculate method if provided input is valid or show error message
		if(operation==1 || operation==2 || operation==3 || operation==4) {
			System.setProperty("webdriver.chrome.driver","driver\\chromedriver.exe");
			
			System.out.println(calculate(input1, input2, operation));	
		}
		else {
			
			System.out.println("Error :: Given operation is not supported! Please choose a correct option between "
					+ "1, 2, 3 or 4");
		}
			
		

	}

}
